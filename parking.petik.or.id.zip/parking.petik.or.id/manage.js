
function tampilkanDataClear() {
    let dataUser = JSON.parse(localStorage.getItem("dataUser")) || [];
    let tabelOutputClear = document.getElementById("tabelOutputclear");

    if (!tabelOutputClear) return; // jika elemen tidak ditemukan di halaman, lewati

    tabelOutputClear.innerHTML = "";

    dataUser.forEach((user, index) => {
        let row = document.createElement("tr");
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${user.pilik}</td>
            <td>${user.noken}</td>
            <td>${user.merken}</td>
            <td>${user.jumlah} ${user.penitipan}</td>
            <td>
                <button class="btn btn-primary" onclick="konfirmasiHapus(${index})">Done</button>
            </td>
        `;
        tabelOutputClear.appendChild(row);
    });
}

// fungsi untuk menampilkan card konfirmasi penghapusan
function konfirmasiHapus(index) {
    let dataUser = JSON.parse(localStorage.getItem("dataUser")) || [];
    let user = dataUser[index];

    let container = document.querySelector(".container");

    // hapus card sebelumnya jika ada
    let existingCard = document.getElementById("cardHapus");
    if (existingCard) existingCard.remove();

    // buat card baru setelah delay 2 detik
    setTimeout(() => {
        let card = document.createElement("div");
        card.id = "cardHapus";
        card.className = "card mt-4";
        card.innerHTML = `
            <div class="card-header">
                <h5>Konfirmasi Penghapusan</h5>
            </div>
            <div class="card-body">
                <p><strong>Pemilik:</strong> ${user.pemilik}</p>
                <p><strong>No. Kendaraan:</strong> ${user.noken}</p>
                <p><strong>Merk Kendaraan:</strong> ${user.merken}</p>
                <p><strong>Jam Penitipan:</strong> ${user.jumlah} ${user.penitipan}</p>
                <p><strong>Total Harga:</strong> Rp ${user.harga.toLocaleString()}</p>
                <button class="btn btn-secondary me-2" onclick="batalHapus()">Cancel</button>
                <button class="btn btn-danger" onclick="hapusData(${index})">Oke</button>
            </div>
        `;
        container.appendChild(card);
    }, 1000);
}

// fungsi untuk membatalkan penghapusan
function batalHapus() {
    let card = document.getElementById("cardHapus");
    if (card) card.remove();
}

// fungsi menghapus data berdasarkan indeks
function hapusData(index) {
    let dataUser = JSON.parse(localStorage.getItem("dataUser")) || [];
    let removedUser = dataUser[index];

    // hapus data dari array
    dataUser.splice(index, 1);

    // simpan perubahan ke localStorage
    localStorage.setItem("dataUser", JSON.stringify(dataUser));

    // refresh tabel
    tampilkanDataClear();

    // hapus card konfirmasi
    batalHapus();

    // tampilkan pesan bahwa data telah dihapus
    alert(`Data milik ${removedUser.pemilik} berhasil dihapus.`);
}

// panggil fungsi tampilkanDataClear saat halaman dimuat
window.onload = tampilkanDataClear;


// smoga ga eyoyy
