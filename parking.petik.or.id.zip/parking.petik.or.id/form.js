
function tambahData() {
    // ambil id nilai dari form input
    let pemilik = document.getElementById("pemilik").value;
    let noken = document.getElementById("noken").value;
    let merken = document.getElementById("merkken").value;
    let jumlah = document.getElementById("jumlah").value;
    let penitipan = document.getElementById("penitipan").value;

    // validasi input
    if (!pemilik || !noken || !merken || !jumlah || !penitipan) {
        alert("Isi semua terlebih dahulu.");
        return;
    }

    // penentuan harga per jam dan per hari
    const hargaPerJam = 5000;
    const hargaPerHari = 50000;

    // hitung harga berdasarkan jenis penitipan yang dipilih
    let harga = 0;
    if (penitipan === "perjam") {
        harga = jumlah * hargaPerJam; // harga per jam
    } else if (penitipan === "perhari") {
        harga = jumlah * hargaPerHari; // harga per hari
    }

    // ambil data lama dari localStorage / sebagai array kosong
    let dataUser = JSON.parse(localStorage.getItem("dataUser")) || [];

    // bikin objek data pengguna baru
    let userData = {
        pemilik: pemilik,
        noken: noken,
        merken: merken,
        penitipan: penitipan === "perjam" ? "Jam" : "Hari",
        jumlah: jumlah,
        harga: harga
    };

    // tambahkan data baru ke array
    dataUser.push(userData);

    // simpen array data ke localStorage
    localStorage.setItem("dataUser", JSON.stringify(dataUser));

    // pindahkan ke halaman output data
    window.location.href = "Dashboard.html"; // ganti URL sesuai halaman tabel (dashboard)
}

// fungsi untuk menampilkan data dari localStorage ke tabel output
function tampilkanData() {
    // ambil data pengguna dari localStorage
    let dataUser = JSON.parse(localStorage.getItem("dataUser")) || [];

    // ambil elemen tbody untuk tabel
    let tabelOutputUser = document.getElementById("tabelOutputUser");

    // kosongkan tabel sebelum menambahkan data
    tabelOutputUser.innerHTML = "";

    // loop untuk menambahkan baris pada tabel
    dataUser.forEach((user, index) => {
        let row = document.createElement("tr");

        row.innerHTML = ` 
            <td>${index + 1}</td>
            <td>${user.pemilik}</td>
            <td>${user.noken}</td>
            <td>${user.merken}</td>
            <td>${user.jumlah} ${user.penitipan}</td>
        `;

        tabelOutputUser.appendChild(row);
    });

    // hitung total kendaraan, total jam, total hari, dan pemasukan
    hitungTotal(dataUser);
}

// fungsi untuk menghitung total kendaraan, total jam, total hari, dan pemasukan
function hitungTotal(dataUser) {
    let totalKendaraanElement = document.getElementById("totalkendaraan");
    let totalJamElement = document.getElementById("totaljam");
    let totalHariElement = document.getElementById("totalhari"); // new element for total days
    let totalPemasukanElement = document.getElementById("totalpemasukan");

    let totalKendaraan = dataUser.length;
    let totalJam = 0;
    let totalHari = 0; // new variable to track total days
    let totalPemasukan = 0;

    // hitung total jam, total hari, dan total pemasukan
    dataUser.forEach(user => {
        if (user.penitipan === "Jam") {
            totalJam += parseInt(user.jumlah); // jumlah jam
            totalPemasukan += user.harga; // total pemasukan per jam
        } else if (user.penitipan === "Hari") {
            totalHari += parseInt(user.jumlah); // jumlah hari
            totalPemasukan += user.harga; // total pemasukan per hari
        }
    });

    // tampilkan total kendaraan, jam, hari, dan pemasukan di elemen
    totalKendaraanElement.textContent = totalKendaraan;
    totalJamElement.textContent = totalJam;
    totalHariElement.textContent = totalHari; // update total hari
    totalPemasukanElement.textContent = totalPemasukan;
}

// panggil fungsi tampilkanData saat halaman dimuat
window.onload = tampilkanData;